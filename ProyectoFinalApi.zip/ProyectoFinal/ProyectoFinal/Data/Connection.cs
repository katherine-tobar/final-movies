﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ProyectoFinal.Data
{
    public class Connection
    {
        public static string routeConnection = "Data Source=LAPTOP-F6GN16DU;Initial Catalog=Movies;User ID=sa;Password=1234";
    }
}